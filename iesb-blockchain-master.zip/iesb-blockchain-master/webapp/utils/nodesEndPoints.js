const node00Endpoint = 'http://localhost:8540';

module.exports = {
    node00Endpoint
}